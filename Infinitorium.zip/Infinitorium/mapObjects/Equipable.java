package mapObjects;
import src.Character;
public interface Equipable {
	
	public abstract void equip(Character player);



}
