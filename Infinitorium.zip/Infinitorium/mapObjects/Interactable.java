package mapObjects;

public interface Interactable {
	
	public abstract void interact();

}
