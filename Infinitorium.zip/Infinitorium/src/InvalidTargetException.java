package src;

public class InvalidTargetException extends Exception{
	public InvalidTargetException()
	{
		super();
	}
	public String getMesage()
	{
		return "Invalid Target Exception!";
	}
	
}
