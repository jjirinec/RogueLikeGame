package src.viewObjects;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double number = 1.0;
		print((number/5.0));
	}
	public static void print(String x) {
		System.out.println(x);
	}
	public static void print(int x) {
		System.out.println(x);
	}
	public static void print(double x) {
		System.out.println(x);
	}
}
